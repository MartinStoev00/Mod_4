package nl.nedap.utility;

public class CommentVisibility {
	public static final String PUBLIC = "public";
	public static final String PRIVATE = "private";
	public static final String PERSONAL = "personal";
}
